@javax.xml.bind.annotation.XmlSchema(namespace = "com.vishal.partdepot")
package com.vishal.widgetstore.services;
